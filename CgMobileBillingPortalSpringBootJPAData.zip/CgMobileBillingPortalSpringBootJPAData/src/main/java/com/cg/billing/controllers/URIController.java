package com.cg.billing.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.billing.beans.Customer;

@Controller
public class URIController 
{
	Customer customer;
	@RequestMapping(value= {"/","index"})
	public String getIndexPage()
	{
		return "indexPage";
	}
	
	@RequestMapping("/registrationPage")
	public String getCustomerDetails()
	{
		return "registrationPage";
	}
	@ModelAttribute
	public Customer Customer()
	{
		customer = new Customer();
		return customer;
	}
	
	
}
