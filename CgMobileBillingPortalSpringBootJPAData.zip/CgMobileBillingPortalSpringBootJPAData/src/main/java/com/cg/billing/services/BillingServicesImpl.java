package com.cg.billing.services;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.billing.beans.Address;
import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.daoservices.BillDAO;
import com.cg.billing.daoservices.CustomerDAO;
import com.cg.billing.daoservices.PlanDAO;
import com.cg.billing.daoservices.PostpaidAccountDAO;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;

@Component("billingServices")
public class BillingServicesImpl implements BillingServices
{
	@Autowired
    private CustomerDAO customerDAO;
	@Autowired
    private PlanDAO planDAO;
	@Autowired
    private BillDAO billDAO;
	@Autowired
    private PostpaidAccountDAO postpaidAccountDAO;
    
	@Override
	public List<Plan> getPlanAllDetails() 
	{
		return planDAO.findAll();
		 
	}

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String dateOfBirth,
			String billingAddressCity, String billingAddressState, int billingAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) {
		List<Address> address = new ArrayList<Address>();
		Address homeAddress = new Address();
		Address billingAddress = new Address();
		address.add(homeAddress);
		address.add(billingAddress);
		Customer customer = new Customer(firstName, lastName, emailId, dateOfBirth,address);
		customerDAO.save(customer);
		return customer.getCustomerId();
	}

	@Override
	public long openPostpaidMobileAccount(int customerId, int planId)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
	    Customer customer = customerDAO.findById(customerId).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer Id:- " + customerId + " Not Found"));
	    Plan plan = planDAO.findById(planId).orElseThrow(()->new PlanDetailsNotFoundException("Sorry Plan Id:- " + planId + " Not Found"));
	    PostpaidAccount postpaidAccount = new PostpaidAccount();
	    postpaidAccount.setCustomer(customer);
	    long mobileNo = postpaidAccount.getMobileNo();
	    PostpaidAccount pa = new PostpaidAccount(mobileNo, plan, customer);
	    postpaidAccountDAO.save(pa);
		return mobileNo;
	}

	@Override
	public double generateMonthlyMobileBill(int customerId, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, PlanDetailsNotFoundException {
		Customer customer = customerDAO.findById(customerId).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer Id:- " + customerId + " Not Found"));
	    PostpaidAccount postpaidAccount = postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("Sorry Mobile No:- " + mobileNo + " Not Found"));
	    Plan plan = postpaidAccount.getPlan();
	    if(plan == null)
	    	throw new PlanDetailsNotFoundException("Sorry Plan Not Found!");
	    if(billMonth.equalsIgnoreCase("January") || billMonth.equalsIgnoreCase("February") || billMonth.equalsIgnoreCase("March") || billMonth.equalsIgnoreCase("April") ||
	    		billMonth.equalsIgnoreCase("May") || billMonth.equalsIgnoreCase("June") || !billMonth.equalsIgnoreCase("July") || billMonth.equalsIgnoreCase("August") ||
	    		billMonth.equalsIgnoreCase("September") || billMonth.equalsIgnoreCase("October") || billMonth.equalsIgnoreCase("November") ||billMonth.equalsIgnoreCase("December"))
	    {
	    	float localSMSAmount = (noOfLocalSMS - plan.getFreeLocalSMS()) <= 0 ? 0 : (noOfLocalSMS - plan.getFreeLocalSMS())*plan.getLocaSMSRate();
	    	float stdSMSAmount = (noOfStdSMS - plan.getFreeStdSMS()) <= 0 ? 0 : (noOfStdSMS - plan.getFreeStdSMS())*plan.getStdSMSRate();
	    	float localCallAmount = (noOfLocalCalls - plan.getFreeLocalCalls()) <= 0 ? 0 : (noOfLocalCalls - plan.getFreeLocalCalls())*plan.getLocalCallRate();
	    	float stdCallAmount = (noOfStdCalls - plan.getFreeStdCalls()) <= 0 ? 0 : (noOfStdCalls - plan.getFreeStdCalls())*plan.getStdCallRate();
	    	float internetDataUsageAmount = (internetDataUsageUnits - plan.getFreeInternetUsageUnits()) <= 0 ? 0 : (internetDataUsageUnits - plan.getFreeInternetUsageUnits())*plan.getInternetDataUsageRate();
	    	float totalBillAmountWithoutTax = localSMSAmount + stdSMSAmount + localCallAmount + stdCallAmount + internetDataUsageAmount + plan.getMonthlyRental();
	    	float cgst = 0.09f * totalBillAmountWithoutTax;
	    	float sgst = 0.09f * totalBillAmountWithoutTax;
	    	float serviceTax = cgst + sgst;
	    	float totalBillAmount = totalBillAmountWithoutTax + serviceTax;
	    	Bill bill = new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth, totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount, stdCallAmount, internetDataUsageAmount, sgst, cgst, postpaidAccount);
	    	billDAO.save(bill);
	    	return (double)totalBillAmount;
	    }
	    else
	    	throw new InvalidBillMonthException("Invalid Month!");
		
	}

	@Override
	public Customer getCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		Customer customer = customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer Id:- " + customerID + " Not Found"));
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		return customerDAO.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Customer customer = customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer Id:- " + customerID + " Not Found"));
	    PostpaidAccount postpaidAccount = postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("Sorry Mobile No:- " + mobileNo + " Not Found"));
		return postpaidAccount;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException {
		Customer customer = customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer Id:- " + customerID + " Not Found"));
		return postpaidAccountDAO.getCustomerAllPostpaidAccountsDetails(customerID);
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException {
		Customer customer = customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer Id:- " + customerID + " Not Found"));
		PostpaidAccount postpaidAccount = postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("Sorry Mobile No:- " + mobileNo + " Not Found"));
	    if(billMonth.equalsIgnoreCase("January") || billMonth.equalsIgnoreCase("February") || billMonth.equalsIgnoreCase("March") || billMonth.equalsIgnoreCase("April") ||
	    		billMonth.equalsIgnoreCase("May") || billMonth.equalsIgnoreCase("June") || !billMonth.equalsIgnoreCase("July") || billMonth.equalsIgnoreCase("August") ||
	    		billMonth.equalsIgnoreCase("September") || billMonth.equalsIgnoreCase("October") || billMonth.equalsIgnoreCase("November") ||billMonth.equalsIgnoreCase("December"))
	    {
	        Bill bill = billDAO.retrieveBill(mobileNo, billMonth);
	        return bill;
	    }
	    else
	    	throw new InvalidBillMonthException("Invalid Month!");
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Customer customer = customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer Id:- " + customerID + " Not Found"));
		PostpaidAccount postpaidAccount = postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("Sorry Mobile No:- " + mobileNo + " Not Found"));
		return billDAO.retrieveAllBills(mobileNo);
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Customer customer = customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer Id:- " + customerID + " Not Found"));
		PostpaidAccount postpaidAccount = postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("Sorry Mobile No:- " + mobileNo + " Not Found"));
	    Plan plan = planDAO.findById(planID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer Id:- " + planID + " Not Found"));
	    postpaidAccount.setPlan(plan);
	    postpaidAccountDAO.save(postpaidAccount);
		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Customer customer = customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer Id:- " + customerID + " Not Found"));
		PostpaidAccount postpaidAccount = postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("Sorry Mobile No:- " + mobileNo + " Not Found"));
	    postpaidAccountDAO.closeCustomerPostpaidAccount(mobileNo);
		return true;
	}

	@Override
	public boolean removeCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		customerDAO.deleteById(customerID);
		return false;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		Customer customer = customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Sorry Customer Id:- " + customerID + " Not Found"));
		PostpaidAccount postpaidAccount = postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("Sorry Mobile No:- " + mobileNo + " Not Found"));
	    return postpaidAccount.getPlan();
	}
	/*public void createPlanDetails()
	{
		planDAO.save(new Plan(501,100,200,100,3000,1000,2,1.5f,1.0f,1.5f,2.5f,50.0f,"Hinjewadi","100Rs"));
		planDAO.save(new Plan(502,200,300,100,4000,2000,3,0.5f,2.0f,1.0f,1.5f,40.0f,"Phase3","200Rs"));
		planDAO.save(new Plan(503,300,400,100,3000,1000,2,1.5f,2.0f,1.0f,2.5f,50.0f,"Balewadi","300Rs"));
		planDAO.save(new Plan(504,400,500,100,4000,2000,3,0.5f,1.0f,1.5f,1.5f,30.0f,"SQS","400Rs"));
	}*/

}
