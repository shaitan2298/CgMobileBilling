package com.cg.billing.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.billing.beans.Bill;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
public interface BillDAO extends JpaRepository<Bill, Integer>
{
	
	@Query("SELECT b from Bill b WHERE b.postpaidAccount.mobileNo = ?1 AND b.billMonth = ?2")
	public Bill retrieveBill(@Param("mobileNo") long mobileNo, @Param("billMonth") String billMonth)throws 
	CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException;
	
	@Query("SELECT b from Bill b WHERE b.postpaidAccount.mobileNo = ?1")
	public List<Bill> retrieveAllBills(@Param("mobileNo") long mobileNo);
}
