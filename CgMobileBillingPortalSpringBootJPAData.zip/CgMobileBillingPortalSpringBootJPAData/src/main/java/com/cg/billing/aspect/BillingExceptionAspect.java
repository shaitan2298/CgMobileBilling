package com.cg.billing.aspect;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;

@ControllerAdvice
public class BillingExceptionAspect 
{
	@ExceptionHandler(CustomerDetailsNotFoundException.class)
    public ModelAndView handelCustomerDetailsNotFoundException(Exception e)
    {
    	return new ModelAndView("","errorMessage",e.getMessage());
    }
	@ExceptionHandler(BillDetailsNotFoundException.class)
    public ModelAndView handelBillDetailsNotFoundException(Exception e)
    {
    	return new ModelAndView("","errorMessage",e.getMessage());
    }
	@ExceptionHandler(InvalidBillMonthException.class)
    public ModelAndView handelInvalidBillMonthException(Exception e)
    {
    	return new ModelAndView("","errorMessage",e.getMessage());
    }
	@ExceptionHandler(PlanDetailsNotFoundException.class)
    public ModelAndView handelPlanDetailsNotFoundException(Exception e)
    {
    	return new ModelAndView("","errorMessage",e.getMessage());
    }
	@ExceptionHandler(PostpaidAccountNotFoundException.class)
    public ModelAndView handelPostpaidAccountNotFoundException(Exception e)
    {
    	return new ModelAndView("","errorMessage",e.getMessage());
    }
}
